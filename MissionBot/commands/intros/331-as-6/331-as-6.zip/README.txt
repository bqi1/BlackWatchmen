Collaborated with: Noone
Used https://stackoverflow.com/questions/4664850/how-to-find-all-occurrences-of-a-substring to find occurences of a substring in a string
Used https://stackoverflow.com/questions/22520932/python-remove-all-non-alphabet-chars-from-string to replace punctuation in problem 5
Used https://stackoverflow.com/questions/1953194/permutations-of-two-lists-in-python to permutate over 2 alphabets
Used https://stackoverflow.com/questions/38709659/what-is-the-faster-way-to-count-substrings-in-string-using-python for faster string occurence finding